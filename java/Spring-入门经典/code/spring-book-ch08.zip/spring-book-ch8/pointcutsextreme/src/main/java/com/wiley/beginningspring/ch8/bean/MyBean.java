package com.wiley.beginningspring.ch8.bean;

import com.wiley.beginningspring.ch8.markers.MarkerInterface;

import org.springframework.stereotype.Component;

/**
 * User: mertcaliskan
 * Date: 25/06/14
 */
public interface MyBean {

    void sayHello();
}