package com.wiley.beginningspring.ch8.markers;

/**
 * Created by mertcaliskan
 * on 18/07/14.
 */
public interface MarkerInterface {
}
