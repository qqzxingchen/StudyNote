package com.wiley.beginningspring.ch8.bean;

/**
 * User: mertcaliskan
 * Date: 25/06/14
 */
public interface MySecondBean {

    void sayHello();
}
