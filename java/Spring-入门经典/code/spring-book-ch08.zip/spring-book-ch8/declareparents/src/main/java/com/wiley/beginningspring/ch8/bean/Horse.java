package com.wiley.beginningspring.ch8.bean;

/**
 * User: mertcaliskan
 * Date: 05/07/14
 */
public class Horse {
    public void ride() {
        System.out.println("Pegasus is wandering..!");
    }
}