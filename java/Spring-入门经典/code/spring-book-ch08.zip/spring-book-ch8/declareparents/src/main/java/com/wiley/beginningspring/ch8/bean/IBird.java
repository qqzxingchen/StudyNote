package com.wiley.beginningspring.ch8.bean;

/**
 * User: mertcaliskan
 * Date: 05/07/14
 */
public interface IBird {
    void fly();
}
