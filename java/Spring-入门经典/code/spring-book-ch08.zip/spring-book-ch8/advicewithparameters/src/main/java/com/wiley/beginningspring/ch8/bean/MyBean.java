package com.wiley.beginningspring.ch8.bean;

/**
 * Created by mertcaliskan
 * on 19/07/14.
 */
public interface MyBean {
    String sayHello(String param);
}
