package com.wiley.beginningspring.ch5;
public interface BookDao {
    public void save(Book book);
}
