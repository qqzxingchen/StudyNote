package com.wiley.beginningspring.ch10;

/**
 * Created by mertcaliskan
 * on 21/08/14.
 */
public class Student extends Person {

    protected Student() {}

    protected Student(int id, String name) {
        super(id, name);
    }
}
