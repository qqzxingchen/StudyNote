package com.wiley.beginningspring.ch9;

/**
 * Created by mertcaliskan
 * on 11/08/14.
 */
public class MyBean {
    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
