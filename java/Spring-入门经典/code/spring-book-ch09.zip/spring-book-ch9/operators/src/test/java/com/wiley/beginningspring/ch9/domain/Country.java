package com.wiley.beginningspring.ch9.domain;

/**
 * Created by mertcaliskan
 * on 14/08/14.
 */
public enum Country {
    TR,
    USA,
    DE
}
