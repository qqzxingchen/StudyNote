package com.wiley.beginningspring.ch9.domain;

/**
 * Created by mertcaliskan
 * on 10/08/14.
 */
public class User {

    private String name;

    public User() {
    }

    public User(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
