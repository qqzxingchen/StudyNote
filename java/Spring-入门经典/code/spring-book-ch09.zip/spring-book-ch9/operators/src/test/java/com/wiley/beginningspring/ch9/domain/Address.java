package com.wiley.beginningspring.ch9.domain;

/**
 * Created by mertcaliskan
 * on 10/08/14.
 */
public class Address {

    private String name;

    public Address(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
