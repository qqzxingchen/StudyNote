package com.wiley.beginningspring.ch2;

public class Foo {

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
