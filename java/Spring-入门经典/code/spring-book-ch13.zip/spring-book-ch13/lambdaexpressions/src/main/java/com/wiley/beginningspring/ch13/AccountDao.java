package com.wiley.beginningspring.ch13;

public interface AccountDao {
    Account find(long accountId);
}

