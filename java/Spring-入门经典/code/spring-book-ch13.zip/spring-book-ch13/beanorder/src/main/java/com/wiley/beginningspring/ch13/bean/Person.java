package com.wiley.beginningspring.ch13.bean;

/**
 * Created by mertcaliskan
 * on 22/10/14.
 */
public abstract class Person {
}
