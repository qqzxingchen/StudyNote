package com.wiley.beginningspring.ch13.service;

/**
 * Created by mertcaliskan
 * on 22/10/14.
 */
public interface NotificationService {

    void notify(String username);
}
