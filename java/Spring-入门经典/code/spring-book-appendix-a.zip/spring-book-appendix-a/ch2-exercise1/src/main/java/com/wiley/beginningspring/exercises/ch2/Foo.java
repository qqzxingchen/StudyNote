package com.wiley.beginningspring.exercises.ch2;

public class Foo {

}
