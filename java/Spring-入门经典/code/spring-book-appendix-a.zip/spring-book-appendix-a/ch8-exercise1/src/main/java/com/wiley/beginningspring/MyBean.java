package com.wiley.beginningspring;

/**
 * Created by mertcaliskan
 * on 23/11/14.
 */
public interface MyBean {

    void sayHi();
}
