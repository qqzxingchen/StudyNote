package com.wiley.beginningspring.exercises.ch1;

public class Foo {
	private Bar bar;
	
	public Foo(Bar bar) {
		this.bar = bar;
	}
}
