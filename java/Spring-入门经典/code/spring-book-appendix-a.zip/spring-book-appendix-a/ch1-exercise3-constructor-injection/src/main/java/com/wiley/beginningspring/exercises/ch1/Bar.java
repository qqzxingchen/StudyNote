package com.wiley.beginningspring.exercises.ch1;

public class Bar {
	private Foo foo;
	
	public Bar(Foo foo) {
		this.foo = foo;
	}
}
