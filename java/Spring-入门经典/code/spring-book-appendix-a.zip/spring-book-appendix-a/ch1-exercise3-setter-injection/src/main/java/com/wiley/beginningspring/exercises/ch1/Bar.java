package com.wiley.beginningspring.exercises.ch1;

public class Bar {
	private Foo foo;
	
	public void setFoo(Foo foo) {
		this.foo = foo;
	}
}
