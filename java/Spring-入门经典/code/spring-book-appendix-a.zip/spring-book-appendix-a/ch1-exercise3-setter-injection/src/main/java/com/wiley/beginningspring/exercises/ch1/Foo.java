package com.wiley.beginningspring.exercises.ch1;

public class Foo {
	private Bar bar;
	
	public void setBar(Bar bar) {
		this.bar = bar;
	}
}
