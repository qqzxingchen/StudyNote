package com.wiley.beginningspring.exercises.ch2;

public class Bar {

	private Foo foo;
	
	public void setFoo(Foo foo) {
		this.foo = foo;
	}

}
