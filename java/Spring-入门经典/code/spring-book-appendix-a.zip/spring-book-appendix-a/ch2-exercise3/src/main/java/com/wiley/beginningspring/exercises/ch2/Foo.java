package com.wiley.beginningspring.exercises.ch2;


public class Foo {
	
	private Bar bar;
	
	public void setBar(Bar bar) {
		this.bar = bar;
	}
}
