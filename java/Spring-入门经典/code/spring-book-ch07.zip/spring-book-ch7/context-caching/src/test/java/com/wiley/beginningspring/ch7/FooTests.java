package com.wiley.beginningspring.ch7;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("/applicationContext.xml")
public class FooTests {
	@Test
	public void testFoo1() {
		
	}
	
	@Test
	public void testFoo2() {
		
	}
}
