package com.wiley.beginningspring.ch7;

public class UserPreferences {
	private String theme;

	public String getTheme() {
		return theme;
	}

	public void setTheme(String theme) {
		this.theme = theme;
	}
}
