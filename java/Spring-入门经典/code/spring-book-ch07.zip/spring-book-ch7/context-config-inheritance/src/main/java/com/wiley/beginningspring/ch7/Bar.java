package com.wiley.beginningspring.ch7;

public class Bar {

}
